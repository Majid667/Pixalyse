import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import AnalyzerForm from './AnalyzerForm';
import AnalysisResult from './AnalysisResult';
import PricingModal from './PricingModal';
import AdSpace from './AdSpace';
import { analyzeContent as analyzeAPI } from '../services/api';
import { Crown } from 'lucide-react';

export default function Dashboard() {
  const { user } = useAuth();
  const [content, setContent] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showPricing, setShowPricing] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyze = async () => {
    if (!content.trim()) return;
    
    setLoading(true);
    setError('');
    setAnalysis(null);

    try {
      const result = await analyzeAPI(content);
      setAnalysis(result.analysis);
    } catch (err) {
      const errorMsg = err.response?.data?.error || 'Analysis failed';
      setError(errorMsg);
      
      if (err.response?.status === 429) {
        setShowPricing(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold text-slate-800 mb-4">
          Analyze Content Reliability
        </h1>
        <p className="text-lg md:text-xl text-slate-600 mb-2">
          Detect bias, verify claims, and assess trustworthiness with AI
        </p>
        {user.subscription_tier === 'free' && (
          <p className="text-sm text-slate-500">
            {3 - (user.daily_usage || 0)} free analyses remaining today
          </p>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <AnalyzerForm
            content={content}
            setContent={setContent}
            onAnalyze={handleAnalyze}
            loading={loading}
            error={error}
          />
          
          {analysis && (
            <AnalysisResult 
              analysis={analysis} 
              userTier={user.subscription_tier}
            />
          )}
        </div>
        
        <div className="space-y-6">
          {user.subscription_tier === 'free' && <AdSpace />}
          
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="font-bold text-slate-800 mb-3">How It Works</h3>
            <ol className="space-y-2 text-sm text-slate-600">
              <li className="flex gap-2">
                <span className="font-semibold text-primary-600">1.</span>
                <span>Paste any content (article, post, news)</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold text-primary-600">2.</span>
                <span>AI analyzes claims and bias</span>
              </li>
              <li className="flex gap-2">
                <span className="font-semibold text-primary-600">3.</span>
                <span>Get trust score and detailed breakdown</span>
              </li>
            </ol>
          </div>

          {user.subscription_tier === 'free' && (
            <div className="bg-gradient-to-br from-primary-500 to-primary-700 rounded-xl shadow-lg p-6 text-white">
              <h3 className="font-bold mb-2 flex items-center gap-2">
                <Crown className="w-5 h-5" />
                Upgrade to Pro
              </h3>
              <p className="text-sm text-primary-50 mb-4">
                Unlimited analyses, no ads, detailed reports
              </p>
              <button
                onClick={() => setShowPricing(true)}
                className="w-full bg-white text-primary-600 py-2 rounded-lg font-semibold hover:bg-primary-50 transition"
              >
                View Plans
              </button>
            </div>
          )}
        </div>
      </div>

      {showPricing && (
        <PricingModal 
          onClose={() => setShowPricing(false)}
          currentTier={user.subscription_tier}
        />
      )}
    </main>
  );
}