// Content Analyzer - Complete Project Generator
// Run this file with Node.js to generate all project files

const fs = require('fs');
const path = require('path');

// Project structure
const projectStructure = {
  '.replit': `run = "npm start"
entrypoint = "server/index.js"

[nix]
channel = "stable-22_11"

[deployment]
run = ["npm", "start"]
deploymentTarget = "cloudrun"

[[ports]]
localPort = 3000
externalPort = 80`,

  'replit.nix': `{ pkgs }: {
  deps = [
    pkgs.nodejs-18_x
    pkgs.nodePackages.typescript-language-server
    pkgs.nodePackages.yarn
    pkgs.nodePackages.pnpm
    pkgs.replitPackages.jest
  ];
}`,

  'package.json': `{
  "name": "content-reliability-analyzer",
  "version": "1.0.0",
  "description": "AI-powered content analysis with subscription monetization",
  "main": "server/index.js",
  "type": "module",
  "scripts": {
    "start": "node server/index.js",
    "dev": "nodemon server/index.js",
    "client": "cd client && npm run dev",
    "build": "cd client && npm run build"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "sqlite3": "^5.1.6",
    "stripe": "^14.7.0",
    "express-rate-limit": "^7.1.5",
    "axios": "^1.6.2",
    "multer": "^1.4.5-lts.1",
    "cheerio": "^1.0.0-rc.12"
  },
  "devDependencies": {
    "nodemon": "^3.0.2"
  }
}`,

  '.gitignore': `node_modules
.pnp
.pnp.js
coverage
dist
build
.DS_Store
.env
.env.local
.env.development.local
.env.test.local
.env.production.local
npm-debug.log*
yarn-debug.log*
yarn-error.log*
pnpm-debug.log*
lerna-debug.log*
.vscode/*
!.vscode/extensions.json
.idea
*.suo
*.ntvs*
*.njsproj
*.sln
*.sw?
.vercel
database/*.db`,

  '.env.example': `# JWT Secret (generate a random string)
JWT_SECRET=your_random_secret_key_here_make_it_long_and_secure

# Stripe Keys (get from stripe.com/dashboard)
STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxx
STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxx

# Stripe Price IDs (create products in Stripe Dashboard)
STRIPE_PRO_PRICE_ID=price_xxxxxxxxxxxxx
STRIPE_BUSINESS_PRICE_ID=price_xxxxxxxxxxxxx

# App Config
CLIENT_URL=https://your-repl-name.your-username.repl.co
PORT=3000`,

  'README.md': `# Content Reliability Analyzer

AI-powered multi-modal content analysis tool.

## Features
- Text, URL, Image, Screenshot, and PDF analysis
- User authentication & subscriptions
- Stripe payment integration
- SQLite database
- Mobile responsive

## Setup on Replit

1. Create new Node.js Repl
2. Copy all files
3. Add Secrets (see .env.example)
4. Run: \`npm install && cd client && npm install && npm run build\`
5. Click Run button

## Tech Stack
- Backend: Node.js, Express, SQLite
- Frontend: React, Vite, Tailwind CSS
- AI: Claude API (Anthropic)
- Payments: Stripe

## License
MIT`,

  'server/index.js': `import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase } from './config/database.js';
import authRoutes from './routes/auth.js';
import analyzeRoutes from './routes/analyze.js';
import subscriptionRoutes from './routes/subscription.js';
import webhookRoutes from './routes/webhook.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

await initDatabase();

app.use(cors({
  origin: process.env.CLIENT_URL || '*',
  credentials: true
}));

app.use('/api/webhook', webhookRoutes);
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

app.use('/api/auth', authRoutes);
app.use('/api/analyze', analyzeRoutes);
app.use('/api/subscription', subscriptionRoutes);

app.use(express.static(path.join(__dirname, '../client/dist')));

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../client/dist/index.html'));
});

app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal server error'
  });
});

app.listen(PORT, () => {
  console.log(\`✅ Server running on port \${PORT}\`);
  console.log(\`🌐 Frontend: http://localhost:\${PORT}\`);
  console.log(\`🔌 API: http://localhost:\${PORT}/api\`);
});`,

  'server/config/database.js': `import sqlite3 from 'sqlite3';
import { promisify } from 'util';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const dbDir = path.join(__dirname, '../../database');
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const dbPath = path.join(dbDir, 'analyzer.db');
const db = new sqlite3.Database(dbPath);

const dbRun = promisify(db.run.bind(db));
const dbGet = promisify(db.get.bind(db));
const dbAll = promisify(db.all.bind(db));

export async function initDatabase() {
  try {
    await dbRun(\`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        subscription_tier TEXT DEFAULT 'free',
        stripe_customer_id TEXT,
        stripe_subscription_id TEXT,
        daily_usage INTEGER DEFAULT 0,
        last_usage_date TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    \`);

    await dbRun(\`
      CREATE TABLE IF NOT EXISTS analyses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        result TEXT NOT NULL,
        trust_score INTEGER,
        analysis_type TEXT DEFAULT 'text',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    \`);

    console.log('✅ Database initialized successfully');
  } catch (error) {
    console.error('❌ Database initialization error:', error);
    throw error;
  }
}

export { db, dbRun, dbGet, dbAll };`,

  'server/middleware/auth.js': `import jwt from 'jsonwebtoken';
import { dbGet } from '../config/database.js';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

export async function authenticateToken(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return res.status(401).json({ error: 'Access token required' });
    }

    const decoded = jwt.verify(token, JWT_SECRET);
    
    const user = await dbGet(
      'SELECT id, email, subscription_tier, daily_usage, last_usage_date FROM users WHERE id = ?',
      [decoded.userId]
    );

    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    return res.status(403).json({ error: 'Invalid or expired token' });
  }
}

export async function checkUsageLimit(req, res, next) {
  try {
    const user = req.user;
    
    if (user.subscription_tier !== 'free') {
      return next();
    }

    const today = new Date().toISOString().split('T')[0];
    const lastUsageDate = user.last_usage_date;

    if (lastUsageDate !== today) {
      const { dbRun } = await import('../config/database.js');
      await dbRun(
        'UPDATE users SET daily_usage = 0, last_usage_date = ? WHERE id = ?',
        [today, user.id]
      );
      user.daily_usage = 0;
    }

    const FREE_LIMIT = 3;
    if (user.daily_usage >= FREE_LIMIT) {
      return res.status(429).json({
        error: 'Daily limit reached',
        message: 'Upgrade to Pro for unlimited analyses',
        limit: FREE_LIMIT,
        usage: user.daily_usage
      });
    }

    next();
  } catch (error) {
    console.error('Usage limit check error:', error);
    next(error);
  }
}`,

  'server/middleware/rateLimit.js': `import rateLimit from 'express-rate-limit';

export const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Too many login attempts, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
});

export const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 3,
  message: 'Too many accounts created, please try again later',
  standardHeaders: true,
  legacyHeaders: false,
});

export const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 20,
  message: 'Too many requests, please slow down',
  standardHeaders: true,
  legacyHeaders: false,
});`,

  'server/routes/auth.js': `import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { dbRun, dbGet } from '../config/database.js';
import { loginLimiter, registerLimiter } from '../middleware/rateLimit.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

router.post('/register', registerLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const existingUser = await dbGet('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await dbRun(
      'INSERT INTO users (email, password) VALUES (?, ?)',
      [email, hashedPassword]
    );

    const token = jwt.sign({ userId: result.lastID }, JWT_SECRET, { expiresIn: '7d' });

    res.status(201).json({
      message: 'User registered successfully',
      token,
      user: {
        id: result.lastID,
        email,
        subscription_tier: 'free'
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password required' });
    }

    const user = await dbGet('SELECT * FROM users WHERE email = ?', [email]);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        subscription_tier: user.subscription_tier,
        daily_usage: user.daily_usage
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

router.get('/me', authenticateToken, async (req, res) => {
  try {
    const user = await dbGet(
      'SELECT id, email, subscription_tier, daily_usage, last_usage_date, created_at FROM users WHERE id = ?',
      [req.user.id]
    );

    res.json({ user });
  } catch (error) {
    console.error('Get user error:', error);
    res.status(500).json({ error: 'Failed to get user data' });
  }
});

export default router;`,

  'server/routes/analyze.js': `// See artifact for full code - too long for this generator
// Copy from the analyze.js artifact above`,

  'server/routes/subscription.js': `// See artifact for full code
// Copy from the subscription.js artifact above`,

  'server/routes/webhook.js': `// See artifact for full code
// Copy from the webhook.js artifact above`,

  'server/utils/anthropic.js': `// See artifact for full code
// Copy from the anthropic.js artifact above`,

  'client/package.json': `{
  "name": "client",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.1",
    "lucide-react": "^0.263.1",
    "axios": "^1.6.2",
    "@stripe/stripe-js": "^2.2.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.43",
    "@types/react-dom": "^18.2.17",
    "@vitejs/plugin-react": "^4.2.1",
    "vite": "^5.0.8",
    "tailwindcss": "^3.3.0",
    "postcss": "^8.4.32",
    "autoprefixer": "^10.4.16"
  }
}`,
};

// Generate project
function generateProject() {
  const projectRoot = './content-analyzer';

  console.log('🚀 Generating Content Analyzer project...\n');

  // Create directories
  const dirs = [
    'server/config',
    'server/middleware',
    'server/routes',
    'server/utils',
    'client/src/components',
    'client/src/contexts',
    'client/src/services',
    'database'
  ];

  dirs.forEach(dir => {
    const fullPath = path.join(projectRoot, dir);
    if (!fs.existsSync(fullPath)) {
      fs.mkdirSync(fullPath, { recursive: true });
      console.log(\`✅ Created directory: \${dir}\`);
    }
  });

  // Create files
  Object.keys(projectStructure).forEach(filePath => {
    const fullPath = path.join(projectRoot, filePath);
    fs.writeFileSync(fullPath, projectStructure[filePath]);
    console.log(\`✅ Created file: \${filePath}\`);
  });

  console.log(\`
\n✅ Project generated successfully!

📁 Location: ./content-analyzer

⚠️  IMPORTANT: Some route files are placeholders. 
Copy the full code from the artifacts above for:
  - server/routes/analyze.js
  - server/routes/subscription.js
  - server/routes/webhook.js
  - server/utils/anthropic.js
  - client/src/* (all React components)

📋 Next steps:
1. cd content-analyzer
2. Copy missing files from chat artifacts
3. npm install
4. cd client && npm install && npm run build
5. Add .env file with your secrets
6. npm start

🎉 Happy coding!
  \`);
}

// Run generator
if (require.main === module) {
  try {
    generateProject();
  } catch (error) {
    console.error('❌ Error generating project:', error);
    process.exit(1);
  }
}

module.exports = { generateProject };