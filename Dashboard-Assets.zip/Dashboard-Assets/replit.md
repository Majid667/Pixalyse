# Pixalyse - AI-Powered Content Analysis

## Overview

Pixalyse is an AI-powered content reliability analyzer that helps users detect bias, verify claims, and assess the trustworthiness of text, URLs, images, and PDFs. The application uses OpenAI's API (via Replit AI Integrations) to perform deep content analysis including trust scoring, bias detection, claim verification, and logical fallacy identification.

The platform operates on a freemium model where free users get 3 daily analyses, while Pro subscribers receive unlimited access.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Animations**: Framer Motion for smooth transitions and visual feedback
- **Design System**: Journalistic aesthetic with Libre Baskerville (serif) for headers and Inter (sans-serif) for body text

### Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **API Pattern**: RESTful endpoints with Zod schema validation for type-safe requests/responses
- **AI Integration**: OpenAI API accessed through Replit AI Integrations environment variables
- **Streaming**: Server-Sent Events (SSE) for real-time analysis streaming to the client
- **Session Management**: Express sessions stored in PostgreSQL via connect-pg-simple

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Key Tables**:
  - `users` and `sessions`: Managed by Replit Auth
  - `analysis_logs`: Stores user analysis history with JSON results
  - `user_subscriptions`: Tracks subscription tier and daily usage limits
  - `conversations` and `messages`: Chat/voice conversation history

### Authentication
- **Provider**: Replit Auth using OpenID Connect
- **Implementation**: Passport.js with custom OIDC strategy
- **Session Storage**: PostgreSQL-backed sessions with 1-week TTL
- **Protected Routes**: `isAuthenticated` middleware guards API endpoints

### Build System
- **Client**: Vite builds to `dist/public`
- **Server**: esbuild bundles server code to `dist/index.cjs` with selective dependency bundling for faster cold starts
- **Development**: Hot module replacement via Vite dev server proxied through Express

## External Dependencies

### AI Services
- **OpenAI API**: Accessed via Replit AI Integrations (`AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL` environment variables)
- **Models Used**: GPT for text analysis, gpt-image-1 for image generation

### Database
- **PostgreSQL**: Connection via `DATABASE_URL` environment variable
- **ORM**: Drizzle ORM with drizzle-kit for migrations (`db:push` command)

### Authentication
- **Replit Auth**: OIDC provider at `https://replit.com/oidc`
- **Required Secrets**: `SESSION_SECRET`, `REPL_ID` (auto-provided by Replit)

### Key NPM Packages
- `openai`: Official OpenAI SDK
- `drizzle-orm` / `drizzle-zod`: Type-safe database queries with Zod integration
- `express-session` / `connect-pg-simple`: Session management
- `passport` / `openid-client`: Authentication
- `@tanstack/react-query`: Client-side data fetching
- `framer-motion`: Animations
- `date-fns`: Date formatting
- `recharts`: Data visualization for trust scores