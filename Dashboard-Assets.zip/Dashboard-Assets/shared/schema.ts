import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";

export * from "./models/auth";

export const analysisLogs = pgTable("analysis_logs", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(), // References auth.users.id
  content: text("content").notNull(),
  result: jsonb("result").notNull(), // Stores the AI analysis
  createdAt: timestamp("created_at").defaultNow(),
});

export const userSubscriptions = pgTable("user_subscriptions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().unique(), // One sub per user
  tier: text("tier").notNull().default("free"), // 'free' | 'pro'
  dailyUsage: integer("daily_usage").default(0),
  lastResetDate: timestamp("last_reset_date").defaultNow(),
});

export const insertAnalysisSchema = createInsertSchema(analysisLogs).omit({ id: true, createdAt: true });
export const insertSubscriptionSchema = createInsertSchema(userSubscriptions).omit({ id: true });

export type AnalysisLog = typeof analysisLogs.$inferSelect;
export type InsertAnalysis = z.infer<typeof insertAnalysisSchema>;
export type UserSubscription = typeof userSubscriptions.$inferSelect;

// API Types
export type AnalyzeRequest = {
  content: string;
};

export type AnalyzeResponse = {
  analysis: {
    trustScore: number;
    biasLevel: "Low" | "Medium" | "High";
    claims: Array<{ claim: string; verdict: "Verified" | "Questionable" | "False"; confidence: number }>;
    fallacies: string[];
    summary: string;
  };
  usage: {
    total: number;
    remaining: number; // For free tier
    isPro: boolean;
  };
};

export type HistoryResponse = AnalysisLog[];

export type UpgradeRequest = {
  tier: "pro";
};
