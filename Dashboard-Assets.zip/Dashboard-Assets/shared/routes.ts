import { z } from 'zod';
import { insertAnalysisSchema, analysisLogs, userSubscriptions } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
  paymentRequired: z.object({
    message: z.string(),
    upgradeUrl: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  analyze: {
    method: 'POST' as const,
    path: '/api/analyze',
    input: z.object({
      content: z.string().optional(),
      url: z.string().url().optional(),
      imageBase64: z.string().optional(),
      contentType: z.enum(["text", "url", "image", "pdf"]).default("text"),
    }),
    responses: {
      200: z.object({
        analysis: z.object({
          trustScore: z.number(),
          biasLevel: z.enum(["Low", "Medium", "High"]),
          claims: z.array(z.object({
            claim: z.string(),
            verdict: z.enum(["Verified", "Questionable", "False"]),
            confidence: z.number(),
          })),
          fallacies: z.array(z.string()),
          summary: z.string(),
        }),
        usage: z.object({
          dailyUsage: z.number(),
          remaining: z.number().nullable(), // Null for pro
          isPro: z.boolean(),
        }),
      }),
      400: errorSchemas.validation,
      401: errorSchemas.unauthorized,
      402: errorSchemas.paymentRequired,
      500: errorSchemas.internal,
    },
  },
  history: {
    method: 'GET' as const,
    path: '/api/history',
    responses: {
      200: z.array(z.custom<typeof analysisLogs.$inferSelect>()),
      401: errorSchemas.unauthorized,
    },
  },
  subscription: {
    get: {
      method: 'GET' as const,
      path: '/api/subscription',
      responses: {
        200: z.custom<typeof userSubscriptions.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    upgrade: {
      method: 'POST' as const,
      path: '/api/subscription/upgrade',
      responses: {
        200: z.custom<typeof userSubscriptions.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
