import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import Parser from "rss-parser";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

async function fetchUrlContent(url: string): Promise<string> {
  try {
    const response = await fetch(url);
    const text = await response.text();
    const cleanText = text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    return cleanText.slice(0, 10000);
  } catch (error) {
    throw new Error("Failed to fetch URL content");
  }
}

async function searchWeb(query: string): Promise<string[]> {
  try {
    const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query + " site:reuters.com OR site:apnews.com OR site:bbc.com OR site:nytimes.com 2024 2025")}`;
    const response = await fetch(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    const html = await response.text();
    
    const results: string[] = [];
    const snippetRegex = /class="result__snippet"[^>]*>([^<]+)</g;
    let match;
    while ((match = snippetRegex.exec(html)) !== null && results.length < 5) {
      const text = match[1].replace(/&[^;]+;/g, ' ').trim();
      if (text.length > 30) {
        results.push(text);
      }
    }
    
    const titleRegex = /class="result__a"[^>]*>([^<]+)</g;
    while ((match = titleRegex.exec(html)) !== null && results.length < 8) {
      const text = match[1].replace(/&[^;]+;/g, ' ').trim();
      if (text.length > 10) {
        results.push(text);
      }
    }
    
    return results.slice(0, 6);
  } catch (error) {
    console.error("Web search error:", error);
    return [];
  }
}

async function extractKeyTerms(content: string): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: "Extract 2-3 key searchable terms/claims from this content that need fact-checking. Return only a JSON array of search queries, nothing else. Focus on specific claims, names, events, or statistics that can be verified."
        },
        { role: "user", content: content.slice(0, 2000) }
      ],
      response_format: { type: "json_object" },
    });
    
    const result = JSON.parse(response.choices[0].message.content || '{"queries":[]}');
    return result.queries || [];
  } catch (error) {
    console.error("Key terms extraction error:", error);
    return [];
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  await setupAuth(app);
  registerAuthRoutes(app);

  app.post("/api/analyze/stream", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims.sub;
      
      const sub = await storage.createOrGetSubscription(userId);
      
      if (sub.tier === 'free' && (sub.dailyUsage || 0) >= 10) {
        return res.status(402).json({
          message: "Daily limit reached. Upgrade to Pro for unlimited analyses.",
          upgradeUrl: "/settings"
        });
      }

      const { content, url, imageBase64, contentType } = req.body;
      
      let analysisContent = "";
      const messages: any[] = [];
      
      if (contentType === "url" && url) {
        analysisContent = await fetchUrlContent(url);
        messages.push({
          role: "user",
          content: `Analyze this web content:\n\n${analysisContent}`
        });
      } else if ((contentType === "image" || contentType === "pdf") && imageBase64) {
        messages.push({
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this image/document for bias, factual accuracy, and logical fallacies. Extract any text and analyze it."
            },
            {
              type: "image_url",
              image_url: {
                url: imageBase64.startsWith("data:") ? imageBase64 : `data:image/jpeg;base64,${imageBase64}`
              }
            }
          ]
        });
        analysisContent = "[Image/PDF Analysis]";
      } else {
        analysisContent = content || "";
        messages.push({
          role: "user",
          content: analysisContent
        });
      }

      if (!analysisContent && !imageBase64) {
        return res.status(400).json({ message: "No content provided for analysis" });
      }

      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');

      let realTimeContext = "";
      
      if (contentType === "image" || contentType === "pdf") {
        res.write(`data: ${JSON.stringify({ type: "chunk", content: "Analyzing visual content...\n\n" })}\n\n`);
      } else {
        res.write(`data: ${JSON.stringify({ type: "chunk", content: "Searching for real-time information...\n\n" })}\n\n`);
        const keyTerms = await extractKeyTerms(analysisContent);
        
        if (keyTerms.length > 0) {
          res.write(`data: ${JSON.stringify({ type: "chunk", content: `Found ${keyTerms.length} claims to verify...\n` })}\n\n`);
          
          const allSearchResults: string[] = [];
          for (const term of keyTerms.slice(0, 3)) {
            const results = await searchWeb(term);
            allSearchResults.push(...results);
          }
          
          if (allSearchResults.length > 0) {
            realTimeContext = `\n\nREAL-TIME SEARCH RESULTS (Use these to verify claims - this is current information from 2024-2025):\n${allSearchResults.map((r, i) => `${i + 1}. ${r}`).join('\n')}\n\n`;
            res.write(`data: ${JSON.stringify({ type: "chunk", content: `Found ${allSearchResults.length} relevant sources. Analyzing...\n\n` })}\n\n`);
          }
        }
      }

      const isVisualContent = contentType === "image" || contentType === "pdf";
      
      const systemPrompt = isVisualContent 
        ? `You are a multilingual Content Reliability Analyzer for visual content. Today's date is ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}.

Analyze this image or document for:
1. Extract ALL text visible in the image/document
2. Identify bias, emotional manipulation, or misleading presentation
3. Verify factual claims if any text is present
4. Check for logical fallacies
5. Assess overall credibility

Respond in the same language as any text found in the image. If no text, respond in English.

Provide a detailed analysis, then output a JSON block at the end wrapped in \`\`\`json ... \`\`\` with:
{
  "trustScore": number (0-100),
  "biasLevel": "Low" | "Medium" | "High",
  "claims": [{ "claim": string, "verdict": "Verified" | "Questionable" | "False", "confidence": number (0-1) }],
  "fallacies": string[],
  "summary": "Brief summary of findings"
}`
        : `You are a multilingual Content Reliability Analyzer with access to REAL-TIME information. 

CRITICAL: Today's date is ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}. 

You have been provided with REAL-TIME SEARCH RESULTS from trusted news sources (Reuters, AP News, BBC, etc.). USE THESE RESULTS to verify claims against current information. Do NOT rely solely on your training data.

${realTimeContext}

Analyze content in ANY language for bias, factual accuracy, and logical fallacies. 

IMPORTANT RULES:
1. Respond in the SAME LANGUAGE as the input content
2. When verifying claims, compare them against the real-time search results provided
3. If a claim contradicts current information from the search results, mark it as "Questionable" or "False"
4. If the search results confirm a claim, mark it as "Verified"
5. Cite specific search results when making verification decisions
6. Be explicit about what is based on current information vs. general knowledge

First, provide a detailed analysis with natural conversational explanations. Reference the search results when verifying specific claims. Then at the very end, output a JSON block wrapped in \`\`\`json ... \`\`\` with this structure:
{
  "trustScore": number (0-100),
  "biasLevel": "Low" | "Medium" | "High",
  "claims": [{ "claim": string, "verdict": "Verified" | "Questionable" | "False", "confidence": number (0-1) }],
  "fallacies": string[],
  "summary": "Brief summary including what real-time sources were used for verification"
}

Be thorough and explain your reasoning step by step, citing the search results when applicable.`;

      const stream = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: systemPrompt },
          ...messages
        ],
        stream: true,
      });

      let fullResponse = "";

      for await (const chunk of stream) {
        const content = chunk.choices[0]?.delta?.content || "";
        if (content) {
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ type: "chunk", content })}\n\n`);
        }
      }

      let analysisResult = {
        trustScore: 75,
        biasLevel: "Medium" as const,
        claims: [],
        fallacies: [],
        summary: "Analysis completed"
      };

      const jsonMatch = fullResponse.match(/```json\s*([\s\S]*?)\s*```/);
      if (jsonMatch) {
        try {
          analysisResult = JSON.parse(jsonMatch[1]);
        } catch (e) {
          console.error("Failed to parse JSON from response");
        }
      }

      await storage.createAnalysisLog({
        userId,
        content: analysisContent.slice(0, 1000),
        result: analysisResult,
      });

      const updatedSub = await storage.incrementUsage(userId);

      res.write(`data: ${JSON.stringify({ 
        type: "complete", 
        analysis: analysisResult,
        usage: {
          dailyUsage: updatedSub.dailyUsage || 0,
          remaining: sub.tier === 'free' ? 10 - (updatedSub.dailyUsage || 0) : null,
          isPro: sub.tier === 'pro',
        }
      })}\n\n`);
      
      res.end();

    } catch (err) {
      console.error("Streaming analysis error:", err);
      res.write(`data: ${JSON.stringify({ type: "error", message: "Analysis failed" })}\n\n`);
      res.end();
    }
  });

  app.post(api.analyze.path, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims.sub;
      
      const sub = await storage.createOrGetSubscription(userId);
      
      if (sub.tier === 'free' && (sub.dailyUsage || 0) >= 10) {
        return res.status(402).json({
          message: "Daily limit reached. Upgrade to Pro for unlimited analyses.",
          upgradeUrl: "/settings"
        });
      }

      const { content } = req.body;

      const completion = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `You are a multilingual Content Reliability Analyzer. Analyze content in ANY language for bias, factual accuracy, and logical fallacies. 
            Respond in the SAME LANGUAGE as the input.
            Return a JSON object with:
            {
              "trustScore": number (0-100),
              "biasLevel": "Low" | "Medium" | "High",
              "claims": [{ "claim": string, "verdict": "Verified" | "Questionable" | "False", "confidence": number (0-1) }],
              "fallacies": string[],
              "summary": "Brief summary"
            }`
          },
          { role: "user", content }
        ],
        response_format: { type: "json_object" },
      });

      const analysisResult = JSON.parse(completion.choices[0].message.content || '{}');

      await storage.createAnalysisLog({
        userId,
        content: content.slice(0, 1000),
        result: analysisResult,
      });

      const updatedSub = await storage.incrementUsage(userId);

      res.json({
        analysis: analysisResult,
        usage: {
          dailyUsage: updatedSub.dailyUsage || 0,
          remaining: sub.tier === 'free' ? 10 - (updatedSub.dailyUsage || 0) : null,
          isPro: sub.tier === 'pro',
        }
      });
    } catch (err) {
      console.error("Analysis error:", err);
      res.status(500).json({ message: "Analysis failed" });
    }
  });

  app.get(api.subscription.get.path, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims.sub;
      
      const sub = await storage.createOrGetSubscription(userId);
      res.json(sub);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.get(api.history.path, isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims.sub;
      
      const logs = await storage.getUserHistory(userId);
      res.json(logs);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  // RSS Feed Analysis endpoint
  app.post("/api/analyze/rss", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims.sub;
      
      const sub = await storage.createOrGetSubscription(userId);
      
      const { feedUrl, limit = 5 } = req.body;
      
      if (!feedUrl) {
        return res.status(400).json({ message: "RSS feed URL is required" });
      }

      const parser = new Parser();
      const feed = await parser.parseURL(feedUrl);
      
      const articles = feed.items.slice(0, Math.min(limit, 10)).map(item => ({
        title: item.title || "Untitled",
        link: item.link || "",
        pubDate: item.pubDate || "",
        contentSnippet: item.contentSnippet?.slice(0, 500) || item.content?.slice(0, 500) || ""
      }));

      // Quick analysis of all articles together
      const articlesText = articles.map((a, i) => 
        `Article ${i + 1}: "${a.title}"\nSnippet: ${a.contentSnippet}`
      ).join("\n\n");

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a Feed Analyzer. Quickly assess the overall reliability and bias of a collection of news articles from an RSS feed.
            Return a JSON object with:
            {
              "overallTrustScore": number (0-100),
              "overallBias": "Left" | "Center-Left" | "Center" | "Center-Right" | "Right" | "Mixed",
              "articles": [{ "title": string, "trustScore": number, "biasIndicator": string }],
              "summary": "Brief overall assessment of the feed source"
            }`
          },
          { role: "user", content: `Analyze these ${articles.length} articles from ${feed.title || feedUrl}:\n\n${articlesText}` }
        ],
        response_format: { type: "json_object" },
      });

      const analysisResult = JSON.parse(completion.choices[0].message.content || '{}');

      res.json({
        feedTitle: feed.title || feedUrl,
        feedDescription: feed.description || "",
        articlesAnalyzed: articles.length,
        articles: articles.map((a, i) => ({
          ...a,
          analysis: analysisResult.articles?.[i] || null
        })),
        overallAnalysis: {
          trustScore: analysisResult.overallTrustScore || 70,
          bias: analysisResult.overallBias || "Unknown",
          summary: analysisResult.summary || "Analysis completed"
        }
      });
    } catch (err) {
      console.error("RSS analysis error:", err);
      res.status(500).json({ message: "Failed to analyze RSS feed" });
    }
  });

  // Batch URL Analysis endpoint
  app.post("/api/analyze/batch", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims.sub;
      
      const sub = await storage.createOrGetSubscription(userId);
      
      const { urls } = req.body;
      
      if (!urls || !Array.isArray(urls) || urls.length === 0) {
        return res.status(400).json({ message: "URLs array is required" });
      }

      const maxUrls = Math.min(urls.length, 5);
      const urlsToAnalyze = urls.slice(0, maxUrls);

      // Check usage limits
      if (sub.tier === 'free' && (sub.dailyUsage || 0) + maxUrls > 10) {
        return res.status(402).json({
          message: `This would exceed your daily limit. You can analyze ${10 - (sub.dailyUsage || 0)} more items today.`,
          upgradeUrl: "/settings"
        });
      }

      // Fetch all URLs in parallel
      const contentPromises = urlsToAnalyze.map(async (url: string) => {
        try {
          const content = await fetchUrlContent(url);
          return { url, content, error: null };
        } catch (e) {
          return { url, content: "", error: "Failed to fetch content" };
        }
      });

      const contents = await Promise.all(contentPromises);
      
      // Analyze all content together for efficiency
      const combinedContent = contents
        .filter(c => c.content)
        .map((c, i) => `URL ${i + 1}: ${c.url}\nContent: ${c.content.slice(0, 2000)}`)
        .join("\n\n---\n\n");

      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          {
            role: "system",
            content: `You are a Batch Content Analyzer. Analyze multiple web pages for reliability and bias.
            Return a JSON object with:
            {
              "results": [
                {
                  "urlIndex": number,
                  "trustScore": number (0-100),
                  "biasLevel": "Low" | "Medium" | "High",
                  "summary": "Brief assessment"
                }
              ],
              "aggregateScore": number (average trust score),
              "overallSummary": "Brief overall assessment"
            }`
          },
          { role: "user", content: `Analyze these ${contents.filter(c => c.content).length} URLs:\n\n${combinedContent}` }
        ],
        response_format: { type: "json_object" },
      });

      const analysisResult = JSON.parse(completion.choices[0].message.content || '{}');

      // Update usage for each URL analyzed
      for (let i = 0; i < contents.filter(c => c.content).length; i++) {
        await storage.incrementUsage(userId);
      }

      const updatedSub = await storage.createOrGetSubscription(userId);

      res.json({
        results: contents.map((c, i) => ({
          url: c.url,
          error: c.error,
          analysis: c.error ? null : analysisResult.results?.find((r: any) => r.urlIndex === i + 1) || {
            trustScore: 70,
            biasLevel: "Medium",
            summary: "Analyzed"
          }
        })),
        aggregate: {
          averageScore: analysisResult.aggregateScore || 70,
          summary: analysisResult.overallSummary || "Batch analysis completed"
        },
        usage: {
          dailyUsage: updatedSub.dailyUsage || 0,
          remaining: sub.tier === 'free' ? 10 - (updatedSub.dailyUsage || 0) : null,
          isPro: sub.tier === 'pro',
        }
      });
    } catch (err) {
      console.error("Batch analysis error:", err);
      res.status(500).json({ message: "Batch analysis failed" });
    }
  });

  return httpServer;
}
