import { db } from "./db";
import { analysisLogs, userSubscriptions, type InsertAnalysis, type UserSubscription } from "@shared/schema";
import { eq, and, sql } from "drizzle-orm";

export interface IStorage {
  // Analysis
  createAnalysisLog(log: InsertAnalysis): Promise<typeof analysisLogs.$inferSelect>;
  getUserHistory(userId: string): Promise<typeof analysisLogs.$inferSelect[]>;
  
  // Subscription
  getUserSubscription(userId: string): Promise<UserSubscription | undefined>;
  createOrGetSubscription(userId: string): Promise<UserSubscription>;
  incrementUsage(userId: string): Promise<UserSubscription>;
  resetDailyUsage(userId: string): Promise<void>;
  upgradeUser(userId: string): Promise<UserSubscription>;
}

export class DatabaseStorage implements IStorage {
  async createAnalysisLog(log: InsertAnalysis) {
    const [entry] = await db.insert(analysisLogs).values(log).returning();
    return entry;
  }

  async getUserHistory(userId: string) {
    return db.select()
      .from(analysisLogs)
      .where(eq(analysisLogs.userId, userId))
      .orderBy(sql`${analysisLogs.createdAt} DESC`);
  }

  async getUserSubscription(userId: string) {
    const [sub] = await db.select().from(userSubscriptions).where(eq(userSubscriptions.userId, userId));
    return sub;
  }

  async createOrGetSubscription(userId: string) {
    let sub = await this.getUserSubscription(userId);
    if (!sub) {
      [sub] = await db.insert(userSubscriptions).values({ userId }).returning();
    }
    
    // Check for daily reset
    const now = new Date();
    const lastReset = new Date(sub.lastResetDate || 0);
    if (now.getDate() !== lastReset.getDate() || now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
      await this.resetDailyUsage(userId);
      sub = (await this.getUserSubscription(userId))!;
    }
    
    return sub;
  }

  async incrementUsage(userId: string) {
    const [updated] = await db.update(userSubscriptions)
      .set({ dailyUsage: sql`${userSubscriptions.dailyUsage} + 1` })
      .where(eq(userSubscriptions.userId, userId))
      .returning();
    return updated;
  }

  async resetDailyUsage(userId: string) {
    await db.update(userSubscriptions)
      .set({ dailyUsage: 0, lastResetDate: new Date() })
      .where(eq(userSubscriptions.userId, userId));
  }

  async upgradeUser(userId: string) {
    const [updated] = await db.update(userSubscriptions)
      .set({ tier: "pro" })
      .where(eq(userSubscriptions.userId, userId))
      .returning();
    return updated;
  }
}

export const storage = new DatabaseStorage();
