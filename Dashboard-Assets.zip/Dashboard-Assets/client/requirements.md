## Packages
framer-motion | Smooth layout transitions and entry animations
recharts | Visualization for trust scores and usage analytics
date-fns | Formatting dates for history logs
clsx | Conditional class merging
tailwind-merge | Tailwind class merging utility

## Notes
- Using Replit Auth (useAuth hook exists)
- API endpoints defined in @shared/routes
- Journalistic aesthetic (Serif headers + Sans body)
