import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

// ============================================
// ANALYSIS HOOKS
// ============================================

export function useAnalyze() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (content: string) => {
      // Client-side validation before request
      const input = api.analyze.input.parse({ content });
      
      const res = await fetch(api.analyze.path, {
        method: api.analyze.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(input),
        credentials: "include",
      });

      if (!res.ok) {
        // Handle explicit error codes
        if (res.status === 402) {
          const error = api.analyze.responses[402].parse(await res.json());
          throw new Error("PAYMENT_REQUIRED"); // Special flag to trigger upgrade modal
        }
        if (res.status === 400) {
          const error = api.analyze.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to analyze content");
      }

      return api.analyze.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      // Refetch history and subscription usage after a successful analysis
      queryClient.invalidateQueries({ queryKey: [api.history.path] });
      queryClient.invalidateQueries({ queryKey: [api.subscription.get.path] });
    },
    onError: (error: Error) => {
      if (error.message !== "PAYMENT_REQUIRED") {
        toast({
          title: "Analysis Failed",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });
}

export function useHistory() {
  return useQuery({
    queryKey: [api.history.path],
    queryFn: async () => {
      const res = await fetch(api.history.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch history");
      return api.history.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// SUBSCRIPTION HOOKS
// ============================================

export function useSubscription() {
  return useQuery({
    queryKey: [api.subscription.get.path],
    queryFn: async () => {
      const res = await fetch(api.subscription.get.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch subscription");
      return api.subscription.get.responses[200].parse(await res.json());
    },
  });
}

export function useUpgrade() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.subscription.upgrade.path, {
        method: api.subscription.upgrade.method,
        credentials: "include",
      });
      
      if (!res.ok) throw new Error("Upgrade failed");
      return api.subscription.upgrade.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.subscription.get.path] });
      toast({
        title: "Welcome to Pro!",
        description: "You now have unlimited analysis access.",
      });
    },
    onError: () => {
      toast({
        title: "Upgrade Failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });
}
