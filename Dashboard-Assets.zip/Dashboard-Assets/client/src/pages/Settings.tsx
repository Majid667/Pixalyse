import { Layout } from "@/components/Layout";
import { useSubscription, useUpgrade } from "@/hooks/use-analysis";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, CreditCard, User } from "lucide-react";

export default function Settings() {
  const { user } = useAuth();
  const { data: subscription } = useSubscription();
  const { mutate: upgrade, isPending } = useUpgrade();

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-serif font-bold text-slate-900">Settings</h1>
          <p className="text-slate-500 mt-2">Manage your account and subscription.</p>
        </div>

        {/* Profile Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Profile Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-slate-500">Full Name</label>
                <p className="text-slate-900">{user?.firstName} {user?.lastName}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-slate-500">Email</label>
                <p className="text-slate-900">{user?.email}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Subscription Card */}
        <Card className={subscription?.tier === 'pro' ? 'border-primary/50 bg-primary/5' : ''}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Subscription Plan
              </CardTitle>
              {subscription?.tier === 'pro' && (
                <Badge className="bg-primary text-white">PRO Active</Badge>
              )}
            </div>
            <CardDescription>
              {subscription?.tier === 'pro' 
                ? "You have unlimited access to all features." 
                : "Upgrade to unlock the full potential of Veritas."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Current Plan</span>
                <span className="font-semibold capitalize">{subscription?.tier || "Free"}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100">
                <span className="text-slate-600">Daily Usage</span>
                <span className="font-semibold">
                  {subscription?.tier === 'pro' ? "Unlimited" : `${subscription?.dailyUsage || 0} / 3`}
                </span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            {subscription?.tier !== 'pro' && (
              <Button 
                onClick={() => upgrade()} 
                disabled={isPending}
                className="w-full sm:w-auto"
              >
                {isPending ? "Processing..." : (
                  <>
                    <Crown className="w-4 h-4 mr-2" />
                    Upgrade to Pro ($9/mo)
                  </>
                )}
              </Button>
            )}
          </CardFooter>
        </Card>
      </div>
    </Layout>
  );
}
