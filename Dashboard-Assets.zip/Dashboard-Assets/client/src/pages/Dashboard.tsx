import { useState, useRef, useCallback } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSubscription } from "@/hooks/use-analysis";
import { UpgradeModal } from "@/components/UpgradeModal";
import { AnalysisReport } from "@/components/AnalysisReport";
import { SocialShare } from "@/components/SocialShare";
import { AdPlaceholder } from "@/components/AdBanner";
import { 
  Loader2, 
  Sparkles, 
  TrendingUp, 
  History, 
  FileText, 
  Link as LinkIcon, 
  Image, 
  Upload, 
  X,
  Zap,
  Globe,
  Shield,
  CheckCircle2
} from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import type { AnalyzeResponse } from "@shared/schema";

type ContentType = "text" | "url" | "image" | "pdf";

export default function Dashboard() {
  const [content, setContent] = useState("");
  const [url, setUrl] = useState("");
  const [contentType, setContentType] = useState<ContentType>("text");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: subscription } = useSubscription();

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const isPdf = file.type === "application/pdf";
    const isImage = file.type.startsWith("image/");

    if (!isPdf && !isImage) {
      toast({
        title: "Invalid file type",
        description: "Please upload an image or PDF file.",
        variant: "destructive",
      });
      return;
    }

    setContentType(isPdf ? "pdf" : "image");

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setImageBase64(base64);
      setImagePreview(base64);
    };
    reader.readAsDataURL(file);
  }, [toast]);

  const clearFile = () => {
    setImagePreview(null);
    setImageBase64(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleAnalyze = async () => {
    if (contentType === "text" && !content.trim()) return;
    if (contentType === "url" && !url.trim()) return;
    if ((contentType === "image" || contentType === "pdf") && !imageBase64) return;

    setIsAnalyzing(true);
    setStreamingText("");
    setResult(null);

    try {
      const response = await fetch("/api/analyze/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          content: contentType === "text" ? content : undefined,
          url: contentType === "url" ? url : undefined,
          imageBase64: (contentType === "image" || contentType === "pdf") ? imageBase64 : undefined,
          contentType,
        }),
      });

      if (response.status === 402) {
        setShowUpgrade(true);
        setIsAnalyzing(false);
        return;
      }

      if (!response.ok) {
        throw new Error("Analysis failed");
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) throw new Error("No reader available");

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));
              
              if (data.type === "chunk") {
                setStreamingText(prev => prev + data.content);
              } else if (data.type === "complete") {
                setResult({
                  analysis: data.analysis,
                  usage: data.usage,
                });
                queryClient.invalidateQueries({ queryKey: ["/api/history"] });
                queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
              } else if (data.type === "error") {
                toast({
                  title: "Analysis Failed",
                  description: data.message,
                  variant: "destructive",
                });
              }
            } catch (e) {
              // Skip invalid JSON
            }
          }
        }
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const usagePercent = subscription 
    ? (subscription.tier === "pro" ? 0 : ((subscription.dailyUsage || 0) / 10) * 100) 
    : 0;

  const canAnalyze = () => {
    if (isAnalyzing) return false;
    if (contentType === "text") return content.trim().length > 0;
    if (contentType === "url") return url.trim().length > 0;
    if (contentType === "image" || contentType === "pdf") return !!imageBase64;
    return false;
  };

  return (
    <Layout>
      {/* Hero Stats Bar */}
      <div className="mb-8 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon: Zap, label: "Real-time AI", value: "Instant" },
          { icon: Globe, label: "Languages", value: "100+" },
          { icon: Shield, label: "Accuracy", value: "95%+" },
          { icon: CheckCircle2, label: "Analyses", value: "10K+" },
        ].map((stat, idx) => (
          <div key={idx} className="bg-card rounded-xl border border-border p-3 md:p-4 flex items-center gap-3">
            <div className="w-8 h-8 md:w-10 md:h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <stat.icon className="w-4 h-4 md:w-5 md:h-5 text-primary" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-muted-foreground truncate">{stat.label}</p>
              <p className="font-semibold text-foreground text-sm md:text-base">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8">
        
        {/* Left Column: Input */}
        <div className="lg:col-span-7 space-y-4 md:space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-serif font-bold text-foreground">Content Analyzer</h1>
              <p className="text-muted-foreground text-sm md:text-base mt-1">Analyze any content for bias, accuracy & credibility</p>
            </div>
          </div>

          <Card className="shadow-lg border-border overflow-hidden">
            <div className="bg-muted/50 border-b border-border p-3 md:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-4">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs md:text-sm font-medium text-muted-foreground">AI Ready - Supports all languages</span>
              </div>
              {subscription?.tier === "free" && (
                <div className="flex items-center gap-2 md:gap-3">
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {10 - (subscription.dailyUsage || 0)}/10 free today
                  </span>
                  <Progress value={usagePercent} className="h-2 w-20 md:w-24" />
                </div>
              )}
              {subscription?.tier === "pro" && (
                <span className="text-xs font-medium text-primary bg-primary/10 px-2 py-1 rounded-full">PRO - Unlimited</span>
              )}
            </div>
            
            <Tabs value={contentType} onValueChange={(v) => setContentType(v as ContentType)} className="w-full">
              <TabsList className="w-full rounded-none border-b border-border bg-card justify-start gap-0 h-auto p-0 overflow-x-auto">
                <TabsTrigger value="text" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-3 md:px-6 py-3 transition-all text-xs md:text-sm whitespace-nowrap" data-testid="tab-text">
                  <FileText className="w-4 h-4 mr-1 md:mr-2" />
                  Text
                </TabsTrigger>
                <TabsTrigger value="url" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-3 md:px-6 py-3 transition-all text-xs md:text-sm whitespace-nowrap" data-testid="tab-url">
                  <LinkIcon className="w-4 h-4 mr-1 md:mr-2" />
                  URL
                </TabsTrigger>
                <TabsTrigger value="image" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-3 md:px-6 py-3 transition-all text-xs md:text-sm whitespace-nowrap" data-testid="tab-image">
                  <Image className="w-4 h-4 mr-1 md:mr-2" />
                  Image/PDF
                </TabsTrigger>
              </TabsList>

              <TabsContent value="text" className="m-0">
                <CardContent className="p-0">
                  <Textarea 
                    placeholder="Paste any text here - news articles, social media posts, blog content, research papers... Works with any language!"
                    className="min-h-[200px] md:min-h-[280px] border-0 focus-visible:ring-0 resize-none p-4 md:p-6 text-sm md:text-base leading-relaxed text-foreground placeholder:text-muted-foreground bg-card"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    data-testid="input-text-content"
                  />
                </CardContent>
              </TabsContent>

              <TabsContent value="url" className="m-0">
                <CardContent className="p-4 md:p-6 min-h-[200px] md:min-h-[280px] flex flex-col justify-center">
                  <div className="space-y-4 max-w-lg mx-auto w-full">
                    <div className="text-center mb-4 md:mb-6">
                      <div className="w-12 h-12 md:w-16 md:h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3 md:mb-4">
                        <LinkIcon className="w-6 h-6 md:w-8 md:h-8 text-primary" />
                      </div>
                      <h3 className="font-semibold text-foreground text-sm md:text-base">Analyze Any Webpage</h3>
                      <p className="text-xs md:text-sm text-muted-foreground mt-1">Enter a URL to analyze its content</p>
                    </div>
                    <Input
                      type="url"
                      placeholder="https://example.com/article"
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      className="text-sm md:text-base py-5 md:py-6 text-center"
                      data-testid="input-url"
                    />
                  </div>
                </CardContent>
              </TabsContent>

              <TabsContent value="image" className="m-0">
                <CardContent className="p-4 md:p-6 min-h-[200px] md:min-h-[280px]">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                    data-testid="input-file"
                  />
                  
                  {imagePreview ? (
                    <div className="relative">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2 z-10 bg-background/90 hover:bg-background shadow-md"
                        onClick={clearFile}
                        data-testid="button-clear-file"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                      {contentType === "pdf" ? (
                        <div className="flex items-center justify-center h-40 md:h-48 bg-destructive/10 rounded-xl border border-destructive/20">
                          <div className="text-center">
                            <FileText className="w-12 h-12 md:w-16 md:h-16 text-destructive/60 mx-auto mb-2" />
                            <p className="text-foreground font-medium text-sm md:text-base">PDF Ready for Analysis</p>
                            <p className="text-xs md:text-sm text-muted-foreground">Click Analyze to start</p>
                          </div>
                        </div>
                      ) : (
                        <img 
                          src={imagePreview} 
                          alt="Preview" 
                          className="max-h-48 md:max-h-56 mx-auto rounded-xl shadow-lg border border-border"
                        />
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full h-40 md:h-48 border-2 border-dashed border-border rounded-xl flex flex-col items-center justify-center gap-2 md:gap-3 hover:border-primary hover:bg-primary/5 transition-all group"
                      data-testid="button-upload"
                    >
                      <div className="w-12 h-12 md:w-16 md:h-16 bg-muted rounded-full flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                        <Upload className="w-6 h-6 md:w-8 md:h-8 text-muted-foreground group-hover:text-primary transition-colors" />
                      </div>
                      <div className="text-center">
                        <p className="font-semibold text-foreground text-sm md:text-base">Drop file or click to upload</p>
                        <p className="text-xs md:text-sm text-muted-foreground">Screenshots, photos, PDFs - max 10MB</p>
                      </div>
                    </button>
                  )}
                </CardContent>
              </TabsContent>
            </Tabs>

            <div className="p-3 md:p-4 bg-muted/30 border-t border-border flex flex-col sm:flex-row justify-between items-center gap-3 md:gap-4">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Globe className="w-3.5 h-3.5" />
                <span>All languages supported</span>
              </div>
              <Button 
                onClick={handleAnalyze} 
                disabled={!canAnalyze()}
                size="default"
                className="w-full sm:w-auto px-6 md:px-8 shadow-lg shadow-primary/20 min-w-[140px] md:min-w-[160px]"
                data-testid="button-analyze"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Analyze Now
                  </>
                )}
              </Button>
            </div>
          </Card>

          {/* Streaming Response */}
          {streamingText && (
            <Card className="shadow-lg border-border overflow-hidden">
              <CardHeader className="bg-green-500/10 dark:bg-green-500/20 border-b border-green-500/20 py-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                  <span className="text-sm font-medium text-green-700 dark:text-green-400">AI Analysis in Progress...</span>
                </div>
              </CardHeader>
              <CardContent className="p-4 md:p-6">
                <div className="prose prose-slate dark:prose-invert max-w-none text-sm leading-relaxed whitespace-pre-wrap">
                  {streamingText.replace(/```json[\s\S]*?```/g, '').replace(/```[\s\S]*?```/g, '').trim()}
                  {isAnalyzing && <span className="inline-block w-2 h-5 bg-primary animate-pulse ml-1 rounded-sm"></span>}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Ad Space */}
          <AdPlaceholder className="h-24" />
        </div>

        {/* Right Column: Results or Stats */}
        <div className="lg:col-span-5 space-y-4 md:space-y-6">
          {result ? (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <h2 className="font-serif font-bold text-lg md:text-xl text-foreground">Analysis Results</h2>
                <SocialShare trustScore={result.analysis.trustScore} />
              </div>
              <AnalysisReport data={result.analysis} />
            </div>
          ) : (
            <div className="space-y-4 md:space-y-6">
              <Card className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white border-0 shadow-xl overflow-hidden">
                <CardContent className="p-5 md:p-8 relative">
                  <div className="absolute top-0 right-0 w-24 md:w-32 h-24 md:h-32 bg-primary/20 rounded-full blur-3xl"></div>
                  <h3 className="text-lg md:text-xl font-serif font-bold mb-2">Upgrade to Pro</h3>
                  <p className="text-slate-300 mb-4 md:mb-6 text-xs md:text-sm leading-relaxed">
                    Get unlimited analyses, deeper insights, priority processing, and no ads.
                  </p>
                  <ul className="space-y-2 mb-4 md:mb-6">
                    {["Unlimited daily analyses", "Priority AI processing", "Ad-free experience", "Export reports"].map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs md:text-sm text-slate-200">
                        <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                  <Button 
                    variant="secondary" 
                    className="w-full font-semibold"
                    onClick={() => setShowUpgrade(true)}
                    data-testid="button-upgrade"
                  >
                    Upgrade Now
                  </Button>
                </CardContent>
              </Card>

              <div className="grid grid-cols-2 gap-3 md:gap-4">
                <Link href="/history">
                  <div className="bg-card p-4 md:p-5 rounded-xl border border-border shadow-sm hover:shadow-lg hover:border-primary/30 transition-all cursor-pointer group" data-testid="link-history">
                    <History className="w-6 h-6 md:w-8 md:h-8 text-muted-foreground group-hover:text-primary mb-2 md:mb-3 transition-colors" />
                    <h4 className="font-semibold text-foreground text-sm md:text-base">History</h4>
                    <p className="text-xs md:text-sm text-muted-foreground">View past reports</p>
                  </div>
                </Link>
                <div className="bg-card p-4 md:p-5 rounded-xl border border-border shadow-sm opacity-75">
                  <TrendingUp className="w-6 h-6 md:w-8 md:h-8 text-muted-foreground mb-2 md:mb-3" />
                  <h4 className="font-semibold text-foreground text-sm md:text-base">Trends</h4>
                  <p className="text-xs md:text-sm text-muted-foreground">Coming soon</p>
                </div>
              </div>

              {/* Ad Space */}
              <AdPlaceholder className="h-48 md:h-64" />
            </div>
          )}
        </div>
      </div>

      <UpgradeModal open={showUpgrade} onOpenChange={setShowUpgrade} />
    </Layout>
  );
}
