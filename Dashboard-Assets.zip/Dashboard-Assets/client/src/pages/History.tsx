import { Layout } from "@/components/Layout";
import { useHistory } from "@/hooks/use-analysis";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Loader2, AlertCircle } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useState } from "react";
import { AnalysisReport } from "@/components/AnalysisReport";
import type { AnalysisLog } from "@shared/schema";

export default function History() {
  const { data: history, isLoading } = useHistory();
  const [selectedLog, setSelectedLog] = useState<AnalysisLog | null>(null);

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-serif font-bold text-slate-900">Analysis History</h1>
          <p className="text-slate-500 mt-2">View your past content verifications.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : history?.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
            <AlertCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-slate-900">No history yet</h3>
            <p className="text-slate-500">Start analyzing content to build your history.</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {history?.map((log) => (
              <Card 
                key={log.id} 
                className="p-6 hover:shadow-md transition-shadow cursor-pointer border-slate-200"
                onClick={() => setSelectedLog(log)}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-500 mb-1">
                      {format(new Date(log.createdAt || ""), "MMM d, yyyy • h:mm a")}
                    </p>
                    <h4 className="font-medium text-slate-900 truncate">
                      {log.content.substring(0, 100)}...
                    </h4>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-xs text-slate-500 uppercase tracking-wider">Trust Score</div>
                      <div className={`text-xl font-bold ${
                        (log.result as any).trustScore >= 80 ? "text-green-600" : 
                        (log.result as any).trustScore >= 50 ? "text-yellow-600" : "text-red-600"
                      }`}>
                        {(log.result as any).trustScore}/100
                      </div>
                    </div>
                    <Badge variant="outline">{(log.result as any).biasLevel} Bias</Badge>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={!!selectedLog} onOpenChange={(open) => !open && setSelectedLog(null)}>
        <DialogContent className="max-w-4xl h-[90vh] overflow-y-auto">
          {selectedLog && (
            <div className="py-4">
              <h2 className="text-2xl font-serif font-bold mb-6">Report Details</h2>
              <AnalysisReport data={(selectedLog.result as any)} />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
