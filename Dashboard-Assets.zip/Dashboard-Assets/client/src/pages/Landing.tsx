import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ShieldCheck, Brain, Lock, ArrowRight, CheckCircle, Eye, Scale, AlertTriangle, Zap, Globe, Users, Star } from "lucide-react";
import { SiFacebook, SiX } from "react-icons/si";
import { useState } from "react";
import { AdPlaceholder } from "@/components/AdBanner";
import { ThemeToggle } from "@/components/ThemeToggle";

function PrivacyPolicy() {
  return (
    <div className="prose prose-slate max-w-none text-sm max-h-96 overflow-y-auto pr-2">
      <h3>Privacy Policy</h3>
      <p><strong>Last Updated:</strong> January 2026</p>
      
      <h4>1. Information We Collect</h4>
      <p>We collect information you provide directly, including:</p>
      <ul>
        <li>Account information (email, name) via Replit authentication</li>
        <li>Content you submit for analysis</li>
        <li>Usage data and analytics</li>
      </ul>
      
      <h4>2. How We Use Your Information</h4>
      <p>We use your information to:</p>
      <ul>
        <li>Provide and improve our content analysis services</li>
        <li>Process your subscription and payments</li>
        <li>Send service-related communications</li>
        <li>Ensure platform security</li>
      </ul>
      
      <h4>3. Data Retention</h4>
      <p>Analysis logs are retained for your reference. You may request deletion of your data at any time by contacting support.</p>
      
      <h4>4. Data Security</h4>
      <p>We implement industry-standard security measures to protect your data. However, no method of transmission over the Internet is 100% secure.</p>
      
      <h4>5. Third-Party Services</h4>
      <p>We use third-party services including Replit for authentication and AI providers for content analysis. These services have their own privacy policies.</p>
      
      <h4>6. Your Rights</h4>
      <p>You have the right to access, correct, or delete your personal data. Contact us to exercise these rights.</p>
      
      <h4>7. Contact</h4>
      <p>For privacy concerns, contact us through the platform support channels.</p>
    </div>
  );
}

function TermsOfService() {
  return (
    <div className="prose prose-slate max-w-none text-sm max-h-96 overflow-y-auto pr-2">
      <h3>Terms of Service</h3>
      <p><strong>Last Updated:</strong> January 2026</p>
      
      <h4>1. Acceptance of Terms</h4>
      <p>By using Pixalyse, you agree to these Terms of Service. If you do not agree, do not use our service.</p>
      
      <h4>2. Description of Service</h4>
      <p>Pixalyse provides AI-powered content analysis for detecting bias, verifying claims, and identifying logical fallacies. The service is provided "as is" without warranties.</p>
      
      <h4>3. User Accounts</h4>
      <ul>
        <li>You must provide accurate account information</li>
        <li>You are responsible for maintaining account security</li>
        <li>You must be at least 18 years old to use this service</li>
      </ul>
      
      <h4>4. Acceptable Use</h4>
      <p>You agree not to:</p>
      <ul>
        <li>Use the service for illegal purposes</li>
        <li>Submit harmful, abusive, or infringing content</li>
        <li>Attempt to circumvent usage limits or security measures</li>
        <li>Resell or redistribute analysis results commercially without permission</li>
      </ul>
      
      <h4>5. Subscription and Payments</h4>
      <ul>
        <li>Free tier includes 3 analyses per day</li>
        <li>Pro tier provides unlimited analyses</li>
        <li>Subscriptions are non-refundable except as required by law</li>
      </ul>
      
      <h4>6. Intellectual Property</h4>
      <p>Pixalyse and its features are owned by us. You retain ownership of content you submit for analysis.</p>
      
      <h4>7. Limitation of Liability</h4>
      <p>We are not liable for any indirect, incidental, or consequential damages arising from your use of the service.</p>
      
      <h4>8. Termination</h4>
      <p>We may terminate or suspend your account for violations of these terms.</p>
      
      <h4>9. Changes to Terms</h4>
      <p>We may update these terms. Continued use constitutes acceptance of changes.</p>
    </div>
  );
}

function Disclaimer() {
  return (
    <div className="prose prose-slate max-w-none text-sm max-h-96 overflow-y-auto pr-2">
      <h3>Disclaimer</h3>
      <p><strong>Last Updated:</strong> January 2026</p>
      
      <h4>AI-Generated Analysis</h4>
      <p><strong>Important:</strong> Pixalyse uses artificial intelligence to analyze content. While we strive for accuracy, our analysis is not infallible and should be used as a supplementary tool, not as the sole basis for decision-making.</p>
      
      <h4>Not Professional Advice</h4>
      <p>Our analysis does not constitute:</p>
      <ul>
        <li>Legal advice</li>
        <li>Journalistic fact-checking certification</li>
        <li>Academic peer review</li>
        <li>Professional editorial assessment</li>
      </ul>
      
      <h4>Accuracy Limitations</h4>
      <ul>
        <li>AI models may produce incorrect or biased results</li>
        <li>Trust scores are estimates based on patterns, not absolute truth</li>
        <li>Results should be verified independently for critical decisions</li>
        <li>The service cannot verify real-time events or breaking news</li>
      </ul>
      
      <h4>No Guarantee</h4>
      <p>We do not guarantee that:</p>
      <ul>
        <li>All biases will be detected</li>
        <li>All claims will be accurately verified</li>
        <li>The service will be error-free or uninterrupted</li>
      </ul>
      
      <h4>User Responsibility</h4>
      <p>You are responsible for:</p>
      <ul>
        <li>Using results responsibly and ethically</li>
        <li>Verifying critical information through additional sources</li>
        <li>Understanding that AI analysis has inherent limitations</li>
      </ul>
      
      <h4>Educational Purpose</h4>
      <p>This tool is designed to help users think critically about content. It should encourage, not replace, independent critical thinking.</p>
    </div>
  );
}

export default function Landing() {
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [disclaimerOpen, setDisclaimerOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      {/* Navigation */}
      <nav className="fixed w-full z-50 bg-background/90 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 md:w-9 md:h-9 bg-primary rounded-lg flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 md:w-5 md:h-5 text-primary-foreground" />
            </div>
            <span className="text-lg md:text-xl font-serif font-bold text-foreground">Pixalyse</span>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <ThemeToggle />
            <a href="/api/login" className="hidden sm:block text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-login">Log In</a>
            <Button asChild className="rounded-full px-4 md:px-6 shadow-lg shadow-primary/20" size="sm" data-testid="button-get-started">
              <a href="/api/login">Get Started</a>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 md:pt-28 md:pb-16 lg:pt-40 lg:pb-24 px-4 overflow-hidden relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-8 md:gap-12 items-center relative">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 md:px-4 py-1.5 md:py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs md:text-sm font-medium mb-4 md:mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              AI-Powered Fact Checking
            </div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-foreground leading-[1.1] mb-4 md:mb-6">
              Detect Bias. <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-blue-600 to-indigo-600">Verify Facts.</span>
            </h1>
            <p className="text-base md:text-lg text-muted-foreground mb-6 md:mb-8 leading-relaxed max-w-lg">
              Instantly analyze news, articles, images and documents for bias, logical fallacies, and factual accuracy. Works in <strong className="text-foreground">100+ languages</strong>.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
              <Button size="lg" className="h-11 md:h-12 px-6 md:px-8 text-sm md:text-base rounded-full shadow-xl shadow-primary/20 hover:scale-105 transition-transform" asChild data-testid="button-cta-primary">
                <a href="/api/login">
                  Start Free Analysis
                  <ArrowRight className="ml-2 w-4 h-4 md:w-5 md:h-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" className="h-11 md:h-12 px-6 md:px-8 text-sm md:text-base rounded-full" asChild>
                <a href="#features">See How It Works</a>
              </Button>
            </div>
            <div className="mt-6 md:mt-8 flex flex-wrap items-center gap-4 md:gap-6 text-xs md:text-sm text-muted-foreground">
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                No credit card required
              </span>
              <span className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                10 free analyses/day
              </span>
            </div>
          </div>

          <div className="relative lg:h-[400px] md:lg:h-[500px] w-full hidden md:flex items-center justify-center">
            <div className="relative w-full max-w-md aspect-[4/5] bg-card rounded-2xl shadow-2xl border border-border p-6 rotate-2 hover:rotate-0 transition-transform duration-500">
              <div className="absolute inset-0 bg-gradient-to-br from-muted to-card rounded-2xl -z-10"></div>
              
              <div className="space-y-4 mb-8">
                <div className="h-4 w-24 bg-muted rounded"></div>
                <div className="h-8 w-3/4 bg-foreground rounded"></div>
                <div className="space-y-2">
                  <div className="h-3 w-full bg-muted rounded"></div>
                  <div className="h-3 w-full bg-muted rounded"></div>
                  <div className="h-3 w-2/3 bg-muted rounded"></div>
                </div>
              </div>

              <div className="bg-card rounded-xl shadow-lg border border-border p-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Trust Score</div>
                    <div className="text-3xl font-serif font-bold text-green-600">92/100</div>
                  </div>
                  <div className="w-14 h-14 rounded-full bg-green-500/10 flex items-center justify-center">
                    <CheckCircle className="w-8 h-8 text-green-500" />
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-foreground">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Claims Verified
                  </div>
                  <div className="flex items-center gap-2 text-sm text-foreground">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    Low Bias Detected
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="py-6 md:py-8 bg-slate-900 dark:bg-slate-950 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 text-center">
            {[
              { value: "10K+", label: "Analyses Completed" },
              { value: "100+", label: "Languages Supported" },
              { value: "95%", label: "Accuracy Rate" },
              { value: "Real-time", label: "AI Responses" },
            ].map((stat, idx) => (
              <div key={idx}>
                <div className="text-xl md:text-2xl lg:text-3xl font-bold text-white">{stat.value}</div>
                <div className="text-xs md:text-sm text-slate-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ad Space */}
      <div className="max-w-7xl mx-auto px-4 py-4 md:py-6">
        <AdPlaceholder className="h-20 md:h-24" />
      </div>

      {/* Features Grid */}
      <section id="features" className="py-12 md:py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-serif font-bold text-foreground mb-3 md:mb-4">Powerful AI Analysis</h2>
            <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto">
              Our advanced AI engine breaks down complex content into actionable insights.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Brain,
                title: "Bias Detection",
                desc: "Identify subjective language, emotional manipulation, and political leaning in seconds.",
                color: "blue"
              },
              {
                icon: ShieldCheck,
                title: "Claim Verification",
                desc: "Cross-reference key claims against verified facts and trusted sources.",
                color: "green"
              },
              {
                icon: Lock,
                title: "Fallacy Finder",
                desc: "Spot logical fallacies like ad hominem attacks, strawman arguments, and more.",
                color: "purple"
              }
            ].map((feature, idx) => (
              <div key={idx} className="p-5 md:p-8 rounded-2xl bg-muted/50 border border-border hover:shadow-xl hover:border-primary/20 transition-all duration-300 group" data-testid={`feature-card-${idx}`}>
                <div className="w-12 h-12 md:w-14 md:h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4 md:mb-6 group-hover:scale-110 transition-transform">
                  <feature.icon className="w-6 h-6 md:w-7 md:h-7 text-primary" />
                </div>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-2 md:mb-3">{feature.title}</h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-12 md:py-20 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-10 md:mb-16">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-serif font-bold text-foreground mb-3 md:mb-4">How It Works</h2>
            <p className="text-base md:text-lg text-muted-foreground">Three simple steps to verify any content</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 md:gap-8">
            {[
              { step: "1", title: "Paste or Upload", desc: "Add text, paste a URL, or upload an image/PDF in any language." },
              { step: "2", title: "AI Analysis", desc: "Our AI analyzes for bias, verifies claims, and identifies fallacies in real-time." },
              { step: "3", title: "Get Results", desc: "Receive a detailed trust score and comprehensive report instantly." },
            ].map((item, idx) => (
              <div key={idx} className="text-center">
                <div className="w-12 h-12 md:w-16 md:h-16 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xl md:text-2xl font-bold mx-auto mb-4 md:mb-6">{item.step}</div>
                <h3 className="text-lg md:text-xl font-bold text-foreground mb-2 md:mb-3">{item.title}</h3>
                <p className="text-sm md:text-base text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 md:py-20 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-serif font-bold mb-4 md:mb-6">Ready to Analyze Content?</h2>
          <p className="text-base md:text-lg text-slate-300 mb-6 md:mb-8 max-w-2xl mx-auto">
            Join thousands of users who trust Pixalyse to verify facts and detect bias. Start your free analysis today.
          </p>
          <Button size="lg" className="h-12 md:h-14 px-8 md:px-10 text-base md:text-lg rounded-full bg-white text-slate-900 hover:bg-slate-100" asChild>
            <a href="/api/login">
              Get Started Free
              <ArrowRight className="ml-2 w-4 h-4 md:w-5 md:h-5" />
            </a>
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 dark:bg-slate-950 text-slate-300 py-10 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 md:gap-12 mb-8 md:mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg md:text-xl font-serif font-bold text-white">Pixalyse</span>
              </div>
              <p className="text-sm md:text-base text-slate-400 max-w-md leading-relaxed mb-4 md:mb-6">
                Empowering critical thinking with AI-powered content analysis. Detect bias, verify claims, and navigate the information age with confidence.
              </p>
              <div className="flex items-center gap-3">
                <span className="text-xs md:text-sm text-slate-500">Follow us:</span>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="w-8 h-8 md:w-9 md:h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors" data-testid="social-twitter">
                  <SiX className="w-4 h-4" />
                </a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="w-8 h-8 md:w-9 md:h-9 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors" data-testid="social-facebook">
                  <SiFacebook className="w-4 h-4" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-3 md:mb-4 text-sm md:text-base">Legal</h4>
              <div className="space-y-2 md:space-y-3">
                <Dialog open={privacyOpen} onOpenChange={setPrivacyOpen}>
                  <DialogTrigger asChild>
                    <button className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm" data-testid="link-privacy">
                      <Eye className="w-4 h-4" />
                      Privacy Policy
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <Eye className="w-5 h-5" />
                        Privacy Policy
                      </DialogTitle>
                    </DialogHeader>
                    <PrivacyPolicy />
                  </DialogContent>
                </Dialog>

                <Dialog open={termsOpen} onOpenChange={setTermsOpen}>
                  <DialogTrigger asChild>
                    <button className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-xs md:text-sm" data-testid="link-terms">
                      <Scale className="w-4 h-4" />
                      Terms of Service
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <Scale className="w-5 h-5" />
                        Terms of Service
                      </DialogTitle>
                    </DialogHeader>
                    <TermsOfService />
                  </DialogContent>
                </Dialog>

                <Dialog open={disclaimerOpen} onOpenChange={setDisclaimerOpen}>
                  <DialogTrigger asChild>
                    <button className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-xs md:text-sm" data-testid="link-disclaimer">
                      <AlertTriangle className="w-4 h-4" />
                      Disclaimer
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <AlertTriangle className="w-5 h-5" />
                        Disclaimer
                      </DialogTitle>
                    </DialogHeader>
                    <Disclaimer />
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-3 md:mb-4 text-sm md:text-base">Product</h4>
              <div className="space-y-2 md:space-y-3">
                <a href="#features" className="block text-slate-400 hover:text-white transition-colors text-xs md:text-sm">Features</a>
                <a href="/api/login" className="block text-slate-400 hover:text-white transition-colors text-xs md:text-sm">Get Started</a>
              </div>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-6 md:pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-xs md:text-sm text-slate-500">
              &copy; {new Date().getFullYear()} Pixalyse. All rights reserved.
            </div>
            <div className="flex items-center gap-6 text-xs text-slate-500">
              <span>AI-powered analysis for educational purposes</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
