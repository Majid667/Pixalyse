import { Button } from "@/components/ui/button";
import { SiFacebook, SiX, SiWhatsapp, SiTiktok, SiInstagram } from "react-icons/si";

interface SocialShareProps {
  title?: string;
  text?: string;
  url?: string;
  trustScore?: number;
}

export function SocialShare({ 
  title = "Check out my content analysis on Pixalyse!", 
  text = "I just analyzed content for bias and accuracy using Pixalyse AI.",
  url = typeof window !== "undefined" ? window.location.href : "",
  trustScore
}: SocialShareProps) {
  
  const shareText = trustScore 
    ? `I analyzed this content and got a Trust Score of ${trustScore}/100! ${text}`
    : text;

  const shareOnTwitter = () => {
    const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(url)}`;
    window.open(twitterUrl, "_blank", "width=600,height=400");
  };

  const shareOnFacebook = () => {
    const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(shareText)}`;
    window.open(facebookUrl, "_blank", "width=600,height=400");
  };

  const shareOnWhatsApp = () => {
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText + " " + url)}`;
    window.open(whatsappUrl, "_blank", "width=600,height=400");
  };

  const shareOnTikTok = () => {
    const tiktokUrl = `https://www.tiktok.com/share?url=${encodeURIComponent(url)}&text=${encodeURIComponent(shareText)}`;
    window.open(tiktokUrl, "_blank", "width=600,height=400");
  };

  const shareOnInstagram = () => {
    navigator.clipboard.writeText(shareText + " " + url);
    alert("Link copied! Open Instagram and paste to share.");
  };

  return (
    <div className="flex items-center gap-1.5 flex-wrap">
      <span className="text-sm text-slate-500 mr-1">Share:</span>
      <Button
        variant="outline"
        size="icon"
        onClick={shareOnWhatsApp}
        className="h-8 w-8 rounded-full bg-green-50 border-green-200 hover:bg-green-100"
        data-testid="button-share-whatsapp"
      >
        <SiWhatsapp className="w-4 h-4 text-green-600" />
      </Button>
      <Button
        variant="outline"
        size="icon"
        onClick={shareOnTwitter}
        className="h-8 w-8 rounded-full"
        data-testid="button-share-twitter"
      >
        <SiX className="w-4 h-4" />
      </Button>
      <Button
        variant="outline"
        size="icon"
        onClick={shareOnFacebook}
        className="h-8 w-8 rounded-full bg-blue-50 border-blue-200 hover:bg-blue-100"
        data-testid="button-share-facebook"
      >
        <SiFacebook className="w-4 h-4 text-blue-600" />
      </Button>
      <Button
        variant="outline"
        size="icon"
        onClick={shareOnTikTok}
        className="h-8 w-8 rounded-full"
        data-testid="button-share-tiktok"
      >
        <SiTiktok className="w-4 h-4" />
      </Button>
      <Button
        variant="outline"
        size="icon"
        onClick={shareOnInstagram}
        className="h-8 w-8 rounded-full bg-pink-50 border-pink-200 hover:bg-pink-100"
        data-testid="button-share-instagram"
      >
        <SiInstagram className="w-4 h-4 text-pink-600" />
      </Button>
    </div>
  );
}
