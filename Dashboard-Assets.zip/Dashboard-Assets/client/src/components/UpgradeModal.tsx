import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Check, ShieldCheck, Sparkles } from "lucide-react";
import { useUpgrade } from "@/hooks/use-analysis";

interface UpgradeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function UpgradeModal({ open, onOpenChange }: UpgradeModalProps) {
  const { mutate: upgrade, isPending } = useUpgrade();

  const handleUpgrade = () => {
    upgrade(undefined, {
      onSuccess: () => onOpenChange(false),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden gap-0">
        <div className="bg-gradient-to-br from-slate-900 to-slate-800 p-8 text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-8 -mr-8 w-32 h-32 bg-primary/30 rounded-full blur-3xl"></div>
          
          <DialogHeader className="relative z-10">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center mb-4 backdrop-blur-sm border border-white/10">
              <Sparkles className="w-6 h-6 text-yellow-300" />
            </div>
            <DialogTitle className="text-2xl font-serif text-white">Upgrade to Pro</DialogTitle>
            <DialogDescription className="text-slate-300 text-base mt-2">
              Unlock unlimited power to verify content and detect bias instantly.
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="p-6 bg-white space-y-6">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-4 h-4 text-green-600" />
              </div>
              <span className="text-slate-700 font-medium">Unlimited daily analysis</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-4 h-4 text-green-600" />
              </div>
              <span className="text-slate-700 font-medium">Deep-dive fallacy reports</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 flex items-center justify-center">
                <Check className="w-4 h-4 text-green-600" />
              </div>
              <span className="text-slate-700 font-medium">Priority processing speed</span>
            </div>
          </div>

          <DialogFooter className="flex-col sm:flex-col gap-3">
            <Button 
              size="lg" 
              className="w-full font-semibold text-lg h-12 shadow-lg shadow-primary/25"
              onClick={handleUpgrade}
              disabled={isPending}
            >
              {isPending ? "Processing..." : "Upgrade Now for $9/mo"}
            </Button>
            <p className="text-center text-xs text-slate-400">
              Secure payment processed via Stripe. Cancel anytime.
            </p>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}
