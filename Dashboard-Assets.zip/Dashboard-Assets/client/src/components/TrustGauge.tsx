import { motion } from "framer-motion";

interface TrustGaugeProps {
  score: number; // 0 to 100
}

export function TrustGauge({ score }: TrustGaugeProps) {
  // Determine color based on score
  const getColor = (s: number) => {
    if (s >= 80) return "#22c55e"; // Green
    if (s >= 50) return "#eab308"; // Yellow
    return "#ef4444"; // Red
  };

  const color = getColor(score);
  const circumference = 2 * Math.PI * 40; // radius 40
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
      <div className="relative w-40 h-40">
        {/* Background Circle */}
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="80"
            cy="80"
            r="40"
            stroke="#f1f5f9"
            strokeWidth="8"
            fill="transparent"
          />
          {/* Progress Circle */}
          <motion.circle
            cx="80"
            cy="80"
            r="40"
            stroke={color}
            strokeWidth="8"
            fill="transparent"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span 
            className="text-4xl font-serif font-bold text-slate-900"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            {score}
          </motion.span>
          <span className="text-xs uppercase tracking-wider text-slate-500 font-semibold mt-1">
            Trust Score
          </span>
        </div>
      </div>
    </div>
  );
}
