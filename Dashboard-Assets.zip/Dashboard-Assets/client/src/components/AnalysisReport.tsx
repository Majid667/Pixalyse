import { motion } from "framer-motion";
import { CheckCircle2, AlertTriangle, XCircle, Info, ChevronDown } from "lucide-react";
import { TrustGauge } from "./TrustGauge";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useState } from "react";
import type { AnalyzeResponse } from "@shared/schema";
import { Card } from "@/components/ui/card";

interface AnalysisReportProps {
  data: AnalyzeResponse['analysis'];
}

export function AnalysisReport({ data }: AnalysisReportProps) {
  return (
    <div className="space-y-8 animate-in">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <TrustGauge score={data.trustScore} />
        </div>
        
        <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3 md:gap-4">
          <Card className="p-4 md:p-6 border-border shadow-sm flex flex-col justify-center">
            <h4 className="text-xs md:text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">Bias Level</h4>
            <div className="flex items-center gap-2 md:gap-3 flex-wrap">
              <Badge 
                variant={data.biasLevel === "High" ? "destructive" : data.biasLevel === "Medium" ? "secondary" : "default"}
                className="text-sm md:text-lg px-3 md:px-4 py-1"
              >
                {data.biasLevel}
              </Badge>
              <span className="text-xs md:text-sm text-muted-foreground">
                {data.biasLevel === "Low" ? "Neutral tone detected" : "Subjective language found"}
              </span>
            </div>
          </Card>
          
          <Card className="p-4 md:p-6 border-border shadow-sm flex flex-col justify-center">
            <h4 className="text-xs md:text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">Fallacies Detected</h4>
            <div className="flex flex-wrap gap-2">
              {data.fallacies.length > 0 ? (
                data.fallacies.map((f, i) => (
                  <Badge key={i} variant="outline" className="bg-orange-500/10 text-orange-700 dark:text-orange-400 border-orange-500/30 text-xs md:text-sm">
                    {f}
                  </Badge>
                ))
              ) : (
                <span className="text-muted-foreground italic text-sm">None detected</span>
              )}
            </div>
          </Card>
        </div>
      </div>

      {/* Summary */}
      <div className="bg-muted/50 rounded-xl p-4 md:p-6 border border-border">
        <h3 className="text-base md:text-lg font-serif font-bold text-foreground mb-2">Executive Summary</h3>
        <p className="text-muted-foreground text-sm md:text-base leading-relaxed">{data.summary}</p>
      </div>

      {/* Claims Analysis */}
      <div>
        <h3 className="text-lg md:text-xl font-serif font-bold text-foreground mb-3 md:mb-4 flex items-center gap-2">
          <Info className="w-4 h-4 md:w-5 md:h-5 text-primary" />
          Claim Verification
        </h3>
        <div className="space-y-3">
          {data.claims.map((claim, idx) => (
            <ClaimItem key={idx} claim={claim} />
          ))}
        </div>
      </div>
    </div>
  );
}

function ClaimItem({ claim }: { claim: AnalyzeResponse['analysis']['claims'][0] }) {
  const [isOpen, setIsOpen] = useState(false);
  
  const getIcon = (verdict: string) => {
    switch (verdict) {
      case "Verified": return <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5 text-green-500" />;
      case "False": return <XCircle className="w-4 h-4 md:w-5 md:h-5 text-red-500" />;
      default: return <AlertTriangle className="w-4 h-4 md:w-5 md:h-5 text-yellow-500" />;
    }
  };

  const getBg = (verdict: string) => {
    switch (verdict) {
      case "Verified": return "bg-green-500/10 border-green-500/30";
      case "False": return "bg-red-500/10 border-red-500/30";
      default: return "bg-yellow-500/10 border-yellow-500/30";
    }
  };

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen} className={`rounded-lg border p-3 md:p-4 transition-all ${getBg(claim.verdict)}`}>
      <div className="flex items-start gap-2 md:gap-3">
        <div className="mt-0.5 shrink-0">{getIcon(claim.verdict)}</div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 sm:gap-2">
            <h4 className="font-medium text-foreground text-sm md:text-base">{claim.claim}</h4>
            <Badge variant="outline" className="self-start sm:self-auto shrink-0 bg-background/50 text-xs">
              {Math.round(claim.confidence * 100)}% Conf.
            </Badge>
          </div>
          <p className="text-xs md:text-sm text-muted-foreground mt-1">Verdict: <span className="font-semibold">{claim.verdict}</span></p>
        </div>
      </div>
    </Collapsible>
  );
}
