import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { 
  ShieldCheck, 
  LayoutDashboard, 
  History, 
  Settings, 
  LogOut,
  User as UserIcon,
  Eye,
  Scale,
  AlertTriangle,
  Menu,
  X
} from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

function PrivacyPolicy() {
  return (
    <div className="prose prose-slate max-w-none text-sm max-h-96 overflow-y-auto pr-2">
      <h3>Privacy Policy</h3>
      <p><strong>Last Updated:</strong> January 2026</p>
      
      <h4>1. Information We Collect</h4>
      <p>We collect information you provide directly, including:</p>
      <ul>
        <li>Account information (email, name) via Replit authentication</li>
        <li>Content you submit for analysis</li>
        <li>Usage data and analytics</li>
      </ul>
      
      <h4>2. How We Use Your Information</h4>
      <p>We use your information to:</p>
      <ul>
        <li>Provide and improve our content analysis services</li>
        <li>Process your subscription and payments</li>
        <li>Send service-related communications</li>
        <li>Ensure platform security</li>
      </ul>
      
      <h4>3. Data Retention</h4>
      <p>Analysis logs are retained for your reference. You may request deletion of your data at any time by contacting support.</p>
      
      <h4>4. Data Security</h4>
      <p>We implement industry-standard security measures to protect your data. However, no method of transmission over the Internet is 100% secure.</p>
      
      <h4>5. Third-Party Services</h4>
      <p>We use third-party services including Replit for authentication and AI providers for content analysis. These services have their own privacy policies.</p>
      
      <h4>6. Your Rights</h4>
      <p>You have the right to access, correct, or delete your personal data. Contact us to exercise these rights.</p>
      
      <h4>7. Contact</h4>
      <p>For privacy concerns, contact us through the platform support channels.</p>
    </div>
  );
}

function TermsOfService() {
  return (
    <div className="prose prose-slate max-w-none text-sm max-h-96 overflow-y-auto pr-2">
      <h3>Terms of Service</h3>
      <p><strong>Last Updated:</strong> January 2026</p>
      
      <h4>1. Acceptance of Terms</h4>
      <p>By using Pixalyse, you agree to these Terms of Service. If you do not agree, do not use our service.</p>
      
      <h4>2. Description of Service</h4>
      <p>Pixalyse provides AI-powered content analysis for detecting bias, verifying claims, and identifying logical fallacies. The service is provided "as is" without warranties.</p>
      
      <h4>3. User Accounts</h4>
      <ul>
        <li>You must provide accurate account information</li>
        <li>You are responsible for maintaining account security</li>
        <li>You must be at least 18 years old to use this service</li>
      </ul>
      
      <h4>4. Acceptable Use</h4>
      <p>You agree not to:</p>
      <ul>
        <li>Use the service for illegal purposes</li>
        <li>Submit harmful, abusive, or infringing content</li>
        <li>Attempt to circumvent usage limits or security measures</li>
        <li>Resell or redistribute analysis results commercially without permission</li>
      </ul>
      
      <h4>5. Subscription and Payments</h4>
      <ul>
        <li>Free tier includes 3 analyses per day</li>
        <li>Pro tier provides unlimited analyses</li>
        <li>Subscriptions are non-refundable except as required by law</li>
      </ul>
      
      <h4>6. Intellectual Property</h4>
      <p>Pixalyse and its features are owned by us. You retain ownership of content you submit for analysis.</p>
      
      <h4>7. Limitation of Liability</h4>
      <p>We are not liable for any indirect, incidental, or consequential damages arising from your use of the service.</p>
      
      <h4>8. Termination</h4>
      <p>We may terminate or suspend your account for violations of these terms.</p>
      
      <h4>9. Changes to Terms</h4>
      <p>We may update these terms. Continued use constitutes acceptance of changes.</p>
    </div>
  );
}

function Disclaimer() {
  return (
    <div className="prose prose-slate max-w-none text-sm max-h-96 overflow-y-auto pr-2">
      <h3>Disclaimer</h3>
      <p><strong>Last Updated:</strong> January 2026</p>
      
      <h4>AI-Generated Analysis</h4>
      <p><strong>Important:</strong> Pixalyse uses artificial intelligence to analyze content. While we strive for accuracy, our analysis is not infallible and should be used as a supplementary tool, not as the sole basis for decision-making.</p>
      
      <h4>Not Professional Advice</h4>
      <p>Our analysis does not constitute:</p>
      <ul>
        <li>Legal advice</li>
        <li>Journalistic fact-checking certification</li>
        <li>Academic peer review</li>
        <li>Professional editorial assessment</li>
      </ul>
      
      <h4>Accuracy Limitations</h4>
      <ul>
        <li>AI models may produce incorrect or biased results</li>
        <li>Trust scores are estimates based on patterns, not absolute truth</li>
        <li>Results should be verified independently for critical decisions</li>
        <li>The service cannot verify real-time events or breaking news</li>
      </ul>
      
      <h4>No Guarantee</h4>
      <p>We do not guarantee that:</p>
      <ul>
        <li>All biases will be detected</li>
        <li>All claims will be accurately verified</li>
        <li>The service will be error-free or uninterrupted</li>
      </ul>
      
      <h4>User Responsibility</h4>
      <p>You are responsible for:</p>
      <ul>
        <li>Using results responsibly and ethically</li>
        <li>Verifying critical information through additional sources</li>
        <li>Understanding that AI analysis has inherent limitations</li>
      </ul>
      
      <h4>Educational Purpose</h4>
      <p>This tool is designed to help users think critically about content. It should encourage, not replace, independent critical thinking.</p>
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const [location] = useLocation();
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [termsOpen, setTermsOpen] = useState(false);
  const [disclaimerOpen, setDisclaimerOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/history", label: "History", icon: History },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-background font-sans flex flex-col">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center gap-4 md:gap-8">
              <Link href="/" className="flex items-center gap-2 group">
                <div className="bg-primary/10 p-2 rounded-lg group-hover:bg-primary/20 transition-colors">
                  <ShieldCheck className="w-5 h-5 md:w-6 md:h-6 text-primary" />
                </div>
                <span className="text-lg md:text-xl font-serif font-bold text-foreground">Pixalyse</span>
              </Link>
              
              {user && (
                <div className="hidden md:flex items-center gap-1">
                  {navItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <div className={`
                        px-4 py-2 rounded-md text-sm font-medium transition-all flex items-center gap-2
                        ${location === item.href 
                          ? "bg-accent text-accent-foreground" 
                          : "text-muted-foreground hover:text-foreground hover:bg-accent/50"}
                      `}>
                        <item.icon className="w-4 h-4" />
                        {item.label}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 md:gap-4">
              <ThemeToggle />
              
              {user ? (
                <>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="md:hidden"
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    data-testid="button-mobile-menu"
                  >
                    {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                  </Button>
                  
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="hidden md:flex rounded-full w-10 h-10 p-0 border border-border" data-testid="button-user-menu">
                        {user.profileImageUrl ? (
                          <img src={user.profileImageUrl} alt={user.firstName || "User"} className="w-full h-full rounded-full object-cover" />
                        ) : (
                          <UserIcon className="w-5 h-5 text-muted-foreground" />
                        )}
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuLabel className="font-normal">
                        <div className="flex flex-col space-y-1">
                          <p className="text-sm font-medium leading-none">{user.firstName} {user.lastName}</p>
                          <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
                        </div>
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => logout()} className="text-red-600 focus:text-red-600" data-testid="button-logout">
                        <LogOut className="mr-2 h-4 w-4" />
                        Log out
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <div className="flex gap-2">
                  <Button variant="ghost" asChild className="hidden sm:flex">
                    <a href="/api/login">Log in</a>
                  </Button>
                  <Button asChild size="sm">
                    <a href="/api/login">Get Started</a>
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {user && mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-background">
            <div className="px-4 py-3 space-y-1">
              {navItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <div 
                    onClick={() => setMobileMenuOpen(false)}
                    className={`
                      px-4 py-3 rounded-md text-sm font-medium transition-all flex items-center gap-3
                      ${location === item.href 
                        ? "bg-accent text-accent-foreground" 
                        : "text-muted-foreground hover:text-foreground hover:bg-accent/50"}
                    `}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </div>
                </Link>
              ))}
              <button 
                onClick={() => { logout(); setMobileMenuOpen(false); }}
                className="w-full px-4 py-3 rounded-md text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950 flex items-center gap-3"
                data-testid="button-mobile-logout"
              >
                <LogOut className="w-5 h-5" />
                Log out
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto flex-1 w-full">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-6 md:py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 md:gap-6">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <span className="text-lg font-serif font-bold text-foreground">Pixalyse</span>
            </div>

            <div className="flex flex-wrap justify-center items-center gap-4 md:gap-6">
              <Dialog open={privacyOpen} onOpenChange={setPrivacyOpen}>
                <DialogTrigger asChild>
                  <button className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm" data-testid="footer-privacy">
                    <Eye className="w-3.5 h-3.5" />
                    Privacy
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Eye className="w-5 h-5" />
                      Privacy Policy
                    </DialogTitle>
                  </DialogHeader>
                  <PrivacyPolicy />
                </DialogContent>
              </Dialog>

              <Dialog open={termsOpen} onOpenChange={setTermsOpen}>
                <DialogTrigger asChild>
                  <button className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm" data-testid="footer-terms">
                    <Scale className="w-3.5 h-3.5" />
                    Terms
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <Scale className="w-5 h-5" />
                      Terms of Service
                    </DialogTitle>
                  </DialogHeader>
                  <TermsOfService />
                </DialogContent>
              </Dialog>

              <Dialog open={disclaimerOpen} onOpenChange={setDisclaimerOpen}>
                <DialogTrigger asChild>
                  <button className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors text-sm" data-testid="footer-disclaimer">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    Disclaimer
                  </button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <AlertTriangle className="w-5 h-5" />
                      Disclaimer
                    </DialogTitle>
                  </DialogHeader>
                  <Disclaimer />
                </DialogContent>
              </Dialog>
            </div>

            <div className="text-sm text-muted-foreground">
              &copy; {new Date().getFullYear()} Pixalyse
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
